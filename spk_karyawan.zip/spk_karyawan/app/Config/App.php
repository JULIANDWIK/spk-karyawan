<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class App extends BaseConfig
{
    // Sesuaikan dengan URL project kamu
    public string $baseURL = 'http://localhost:8080/';

    public array $allowedHostnames = [];

    // DIKOSONGKAN agar URL lebih bersih (tanpa index.php)
    public string $indexPage = '';

    public string $uriProtocol = 'REQUEST_URI';

    public string $permittedURIChars = 'a-z 0-9~%.:_\-';

    // Sesuaikan bahasa jika diperlukan
    public string $defaultLocale = 'id';

    public bool $negotiateLocale = false;

    public array $supportedLocales = ['en', 'id'];

    // SESUAIKAN ke Waktu Indonesia Barat
    public string $appTimezone = 'Asia/Jakarta';

    public string $charset = 'UTF-8';

    public bool $forceGlobalSecureRequests = false;

    public array $proxyIPs = [];

    public bool $CSPEnabled = false;
}