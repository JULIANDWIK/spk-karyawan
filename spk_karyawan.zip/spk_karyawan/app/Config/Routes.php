<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// --- ROUTE OTENTIKASI ---
$routes->get('/', 'Auth::login'); 
$routes->get('login', 'Auth::login');
$routes->post('auth/proses_login', 'Auth::proses_login');
$routes->get('auth/logout', 'Auth::logout');

// --- ROUTE DASHBOARD ---
$routes->get('dashboard', 'Dashboard::index');

// --- ROUTE ALTERNATIF & KARYAWAN ---
// Kita buat dua grup yang mengarah ke Controller yang sama agar link tidak error
$routes->group('alternatif', function($routes) {
    $routes->get('/', 'Alternatif::index'); 
    $routes->get('tambah', 'Alternatif::tambah'); 
    $routes->post('simpan', 'Alternatif::simpan');
    $routes->get('edit/(:num)', 'Alternatif::edit/$1');
    $routes->post('update/(:num)', 'Alternatif::update/$1'); 
    $routes->get('hapus/(:num)', 'Alternatif::hapus/$1');
});

// Menambahkan grup karyawan agar link karyawan/hapus/(:num) bisa ditemukan
$routes->group('karyawan', function($routes) {
    $routes->get('/', 'Alternatif::index'); 
    $routes->get('tambah', 'Alternatif::tambah'); 
    $routes->post('simpan', 'Alternatif::simpan');
    $routes->get('edit/(:num)', 'Alternatif::edit/$1');
    $routes->post('update/(:num)', 'Alternatif::update/$1'); 
    $routes->get('hapus/(:num)', 'Alternatif::hapus/$1');
});

// --- ROUTE KRITERIA ---
$routes->group('kriteria', function($routes) {
    $routes->get('/', 'Kriteria::index');
    $routes->get('tambah', 'Kriteria::tambah');
    $routes->post('simpan', 'Kriteria::simpan');
    $routes->get('edit/(:num)', 'Kriteria::edit/$1');
    $routes->post('update/(:num)', 'Kriteria::update/$1'); 
    $routes->get('hapus/(:num)', 'Kriteria::hapus/$1');
});

// --- ROUTE PENILAIAN ---
$routes->group('penilaian', function($routes) {
    $routes->get('/', 'Penilaian::index');
    $routes->post('simpan', 'Penilaian::simpan');
    $routes->get('hitung', 'Penilaian::hitung');
});

// --- ROUTE HASIL / PERHITUNGAN WP ---
$routes->get('hasil-peringkat', 'Hasil::index'); 
$routes->get('hasil', 'Hasil::index');
$routes->get('perhitungan', 'Hasil::index');