<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id_user';
    protected $allowedFields    = ['username', 'password', 'nama_lengkap', 'role'];

    // Jika kamu ingin tetap pakai fitur otomatis waktu:
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = ''; // Kosongkan jika di DB tidak ada updated_at
}