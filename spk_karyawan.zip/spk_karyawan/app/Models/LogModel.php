<?php

namespace App\Models;

use CodeIgniter\Model;

class LogModel extends Model
{
    protected $table            = 'log_aktivitas';
    protected $primaryKey       = 'id_log';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['id_user', 'aktivitas', 'keterangan'];

    // Aktifkan Fitur Timestamps agar created_at terisi otomatis
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = ''; // Kosongkan karena tabel tidak punya updated_at

    /**
     * Menyimpan log aktivitas user ke database
     */
    public function simpanLog($aktivitas, $keterangan = "")
    {
        $this->save([
            'id_user'    => session()->get('id_user') ?? 0, // Beri default 0 jika session kosong
            'aktivitas'  => $aktivitas,
            'keterangan' => $keterangan
        ]);
    }
}