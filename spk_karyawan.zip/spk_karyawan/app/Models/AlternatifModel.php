<?php

namespace App\Models;

use CodeIgniter\Model;

class AlternatifModel extends Model
{
    protected $table            = 'alternatif';
    protected $primaryKey       = 'id_alternatif';
    protected $useAutoIncrement = true;
    
    // PERBAIKAN: Ganti 'jabatan' menjadi 'posisi' sesuai database kamu
    protected $allowedFields    = ['nama_karyawan', 'posisi'];

    protected $useTimestamps    = false; 
}