<?php

namespace App\Models;

use CodeIgniter\Model;

class KriteriaModel extends Model
{
    // Nama tabel sesuai di database kamu
    protected $table            = 'kriteria';
    
    // Primary key sesuai di database kamu
    protected $primaryKey       = 'id_kriteria';
    
    protected $useAutoIncrement = true;

    /**
     * Field yang diizinkan untuk diisi (Allowed Fields).
     * Harus sama persis dengan kolom di database agar tidak NULL.
     */
    protected $allowedFields    = ['nama_kriteria', 'bobot', 'tipe'];

    // Kamu tidak menggunakan fitur timestamps (created_at/updated_at) di tabel ini
    protected $useTimestamps    = false; 
}