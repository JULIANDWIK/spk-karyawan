<?php

namespace App\Models;

use CodeIgniter\Model;

class PenilaianModel extends Model
{
    protected $table            = 'penilaian';
    protected $primaryKey       = 'id_penilaian';
    protected $useAutoIncrement = true;
    
    // Sesuaikan dengan kolom di database kamu
    protected $allowedFields    = ['id_alternatif', 'id_kriteria', 'nilai'];

    /**
     * Ambil semua nilai penilaian untuk satu alternatif tertentu.
     * Fungsi ini berguna saat kamu ingin mengedit nilai per karyawan.
     */
    public function getNilaiByAlternatif($id_alternatif)
    {
        return $this->where('id_alternatif', $id_alternatif)->findAll();
    }

    /**
     * Ambil nilai lengkap dengan nama kriteria (Join ke tabel kriteria).
     * Berguna untuk menampilkan tabel penilaian di halaman depan.
     */
    public function getPenilaianLengkap()
    {
        return $this->select('penilaian.*, kriteria.nama_kriteria, alternatif.nama_karyawan')
                    ->join('kriteria', 'kriteria.id_kriteria = penilaian.id_kriteria')
                    ->join('alternatif', 'alternatif.id_alternatif = penilaian.id_alternatif')
                    ->findAll();
    }
}