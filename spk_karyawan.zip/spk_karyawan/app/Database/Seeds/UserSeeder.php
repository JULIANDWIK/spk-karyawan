<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'username'      => 'admin',
                'password'      => password_hash('admin123', PASSWORD_BCRYPT),
                'nama_lengkap'  => 'Administrator Utama',
                'role'          => 'admin'
            ],
            [
                'username'      => 'manager',
                'password'      => password_hash('manager123', PASSWORD_BCRYPT),
                'nama_lengkap'  => 'HR Manager',
                'role'          => 'manager'
            ],
        ];
        $this->db->table('users')->insertBatch($data);
    }
}