<?php

namespace App\Controllers;

use App\Models\AlternatifModel;
use App\Models\KriteriaModel;
use App\Models\PenilaianModel;
use App\Models\LogModel;

class Penilaian extends BaseController
{
    protected $altModel, $kritModel, $penModel, $logModel;

    public function __construct()
    {
        $this->altModel = new AlternatifModel();
        $this->kritModel = new KriteriaModel();
        $this->penModel = new PenilaianModel();
        $this->logModel = new LogModel();
    }

    public function index()
    {
        $karyawan = $this->altModel->findAll();
        $kriteria = $this->kritModel->findAll();
        $dataNilai = $this->penModel->findAll();
        
        $nilaiMap = [];
        foreach ($dataNilai as $n) {
            $nilaiMap[$n['id_alternatif']][$n['id_kriteria']] = $n['nilai'];
        }

        $data = [
            'title'    => 'Input Nilai Karyawan',
            'karyawan' => $karyawan,
            'kriteria' => $kriteria,
            'nilaiMap' => $nilaiMap
        ];

        return view('penilaian/index', $data);
    }

    public function simpan()
    {
        $postNilai = $this->request->getPost('nilai');

        if ($postNilai) {
            $db = \Config\Database::connect();
            $db->transStart();

            foreach ($postNilai as $id_alt => $kriteria_nilai) {
                foreach ($kriteria_nilai as $id_krit => $skor) {
                    $ada = $this->penModel->where([
                        'id_alternatif' => $id_alt, 
                        'id_kriteria'   => $id_krit
                    ])->first();

                    if ($ada) {
                        $this->penModel->update($ada['id_penilaian'], ['nilai' => $skor]);
                    } else {
                        $this->penModel->insert([
                            'id_alternatif' => $id_alt,
                            'id_kriteria'   => $id_krit,
                            'nilai'         => $skor
                        ]);
                    }
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return redirect()->back()->with('error', 'Gagal menyimpan nilai.');
            }

            return $this->hitung();
        }

        return redirect()->back()->with('error', 'Data tidak ditemukan.');
    }

    public function hitung()
    {
        $kriteria = $this->kritModel->findAll();
        $alternatif = $this->altModel->findAll();
        
        if (empty($alternatif)) {
            return redirect()->to(base_url('penilaian'))->with('error', 'Data karyawan kosong.');
        }

        // 1. Normalisasi Bobot W
        $total_bobot = 0;
        foreach ($kriteria as $k) {
            $total_bobot += $k['bobot'];
        }

        $bobot_kepentingan = [];
        foreach ($kriteria as $k) {
            $pangkat = ($k['tipe'] == 'benefit') ? 1 : -1;
            $bobot_kepentingan[$k['id_kriteria']] = ($k['bobot'] / $total_bobot) * $pangkat;
        }

        // 2. Menghitung Vektor S
        $vektor_s = [];
        $total_vektor_s = 0;
        foreach ($alternatif as $alt) {
            $s_value = 1;
            foreach ($kriteria as $k) {
                $nilai = $this->penModel->where([
                    'id_alternatif' => $alt['id_alternatif'],
                    'id_kriteria' => $k['id_kriteria']
                ])->first();
                
                $skor = $nilai ? $nilai['nilai'] : 1;
                $s_value *= pow($skor, $bobot_kepentingan[$k['id_kriteria']]);
            }
            $vektor_s[$alt['id_alternatif']] = $s_value;
            $total_vektor_s += $s_value;
        }

        // 3. Menghitung Vektor V & Sorting untuk Ranking
        $hasil_akhir = [];
        foreach ($alternatif as $alt) {
            $v_value = $vektor_s[$alt['id_alternatif']] / $total_vektor_s;
            $hasil_akhir[] = [
                'id_alternatif' => $alt['id_alternatif'],
                'nilai_v'       => $v_value
            ];
        }

        // Urutkan data berdasarkan nilai_v dari yang tertinggi
        usort($hasil_akhir, function($a, $b) {
            return $b['nilai_v'] <=> $a['nilai_v'];
        });

        // 4. Simpan ke Database (Kolom Lengkap)
        $db = \Config\Database::connect();
        $db->table('hasil_wp')->emptyTable(); 

        $rank = 1;
        foreach ($hasil_akhir as $h) {
            $db->table('hasil_wp')->insert([
                'id_alternatif' => $h['id_alternatif'],
                'nilai_v'       => $h['nilai_v'],
                'ranking'       => $rank++,
                'periode'       => date('F Y'),
                'tanggal_hitung'=> date('Y-m-d')
            ]);
        }

        $this->logModel->simpanLog("Hitung WP", "Melakukan kalkulasi peringkat dan memperbarui database.");
        return redirect()->to(base_url('hasil-peringkat'))->with('success', 'Perhitungan berhasil. Ranking dan Periode telah diperbarui.');
    }
}