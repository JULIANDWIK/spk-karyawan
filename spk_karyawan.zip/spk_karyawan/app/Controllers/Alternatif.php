<?php

namespace App\Controllers;

use App\Models\AlternatifModel;

class Alternatif extends BaseController
{
    protected $altModel;

    public function __construct()
    {
        $this->altModel = new AlternatifModel();
    }

    public function index()
    {
        $data = [
            'title'      => 'Data Karyawan',
            'alternatif' => $this->altModel->findAll()
        ];

        return view('alternatif/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Karyawan'
        ];
        return view('alternatif/tambah', $data);
    }

    public function simpan()
    {
        // Mengambil data dari form sesuai kolom database kamu
        $this->altModel->save([
            'nama_karyawan' => $this->request->getPost('nama_karyawan'),
            'posisi'        => $this->request->getPost('posisi'),
        ]);

        return redirect()->to(base_url('alternatif'))->with('success', 'Data berhasil disimpan.');
    }

    public function edit($id)
    {
        $data = [
            'title'      => 'Edit Karyawan',
            'alternatif' => $this->altModel->find($id)
        ];

        if (empty($data['alternatif'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data tidak ditemukan');
        }

        return view('alternatif/edit', $data);
    }

    public function update($id)
    {
        $this->altModel->update($id, [
            'nama_karyawan' => $this->request->getPost('nama_karyawan'),
            'posisi'        => $this->request->getPost('posisi'),
        ]);

        return redirect()->to(base_url('alternatif'))->with('success', 'Data berhasil diupdate.');
    }

    public function hapus($id)
    {
        $this->altModel->delete($id);
        return redirect()->to(base_url('alternatif'))->with('success', 'Data berhasil dihapus.');
    }
}