<?php

namespace App\Controllers;

use App\Models\AlternatifModel;
use App\Models\KriteriaModel;
use App\Models\PenilaianModel;
use App\Models\LogModel;

class Perhitungan extends BaseController
{
    protected $altModel, $kritModel, $penModel, $logModel;

    public function __construct()
    {
        $this->altModel = new AlternatifModel();
        $this->kritModel = new KriteriaModel();
        $this->penModel = new PenilaianModel();
        $this->logModel = new LogModel();
    }

    public function index()
    {
        $karyawan = $this->altModel->findAll();
        $kriteria = $this->kritModel->findAll();
        $penilaian = $this->penModel->findAll();

        // Cek apakah data sudah lengkap
        if (empty($karyawan) || empty($kriteria) || empty($penilaian)) {
            return redirect()->to(base_url('penilaian'))->with('error', 'Data karyawan, kriteria, atau penilaian belum lengkap!');
        }

        // 1. Map Penilaian ke Array [id_alt][id_krit]
        $nilaiArr = [];
        foreach ($penilaian as $p) {
            $nilaiArr[$p['id_alternatif']][$p['id_kriteria']] = $p['nilai'];
        }

        // 2. Hitung Total Bobot untuk Normalisasi
        $sumBobot = array_sum(array_column($kriteria, 'bobot'));

        // 3. Hitung Vektor S (Normalisasi Bobot & Pangkat)
        $S = [];
        $totalS = 0;
        foreach ($karyawan as $kary) {
            $si = 1;
            foreach ($kriteria as $krit) {
                // Ambil nilai, jika kosong beri default 1 agar tidak merusak perkalian
                $skor = $nilaiArr[$kary['id_alternatif']][$krit['id_kriteria']] ?? 1;
                
                // Normalisasi Bobot (Wj)
                $wj = $krit['bobot'] / $sumBobot;
                
                // Jika kriteria adalah COST, maka pangkatnya negatif
                if (strtolower($krit['tipe']) == 'cost') {
                    $wj = -$wj;
                }
                
                // Rumus Vektor S: Nilai dipangkatkan bobot normalisasi
                $si *= pow($skor, $wj);
            }
            $S[$kary['id_alternatif']] = $si;
            $totalS += $si;
        }

        // 4. Hitung Vektor V (Ranking Akhir)
        $ranking = [];
        foreach ($karyawan as $kary) {
            $vi = ($totalS > 0) ? ($S[$kary['id_alternatif']] / $totalS) : 0;
            $ranking[] = [
                // PERBAIKAN: Menggunakan 'posisi' sesuai database kamu
                'nama'    => $kary['nama_karyawan'],
                'posisi'  => $kary['posisi'], 
                'vektor_s'=> round($S[$kary['id_alternatif']], 4),
                'nilai_v' => round($vi, 4)
            ];
        }

        // 5. Urutkan berdasarkan Nilai V tertinggi
        usort($ranking, function($a, $b) {
            return $b['nilai_v'] <=> $a['nilai_v'];
        });

        $data = [
            'title'   => 'Hasil Perhitungan WP',
            'ranking' => $ranking
        ];

        $this->logModel->simpanLog("Hitung WP", "Admin melihat hasil ranking Weighted Product.");
        
        // Pastikan folder di Views bernama 'hasil' sesuai gambar folder kamu sebelumnya
        return view('hasil/index', $data); 
    }
}