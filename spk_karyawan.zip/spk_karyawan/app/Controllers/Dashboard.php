<?php

namespace App\Controllers;

use App\Models\AlternatifModel;
use App\Models\KriteriaModel;
use App\Models\LogModel;

class Dashboard extends BaseController
{
    protected $altModel, $kritModel, $logModel;

    public function __construct()
    {
        $this->altModel = new AlternatifModel();
        $this->kritModel = new KriteriaModel();
        $this->logModel = new LogModel();
    }

    public function index()
    {
        // 1. Ambil statistik dasar
        $total_alternatif = $this->altModel->countAllResults();
        $total_kriteria   = $this->kritModel->countAllResults();
        
        // 2. Ambil data dari tabel hasil_wp di-join dengan tabel alternatif
        // Menggunakan LEFT JOIN agar grafik tidak error jika data hasil_wp belum terisi
        $rankingData = $this->altModel->select('alternatif.nama_karyawan, hasil_wp.nilai_v')
                        ->join('hasil_wp', 'hasil_wp.id_alternatif = alternatif.id_alternatif', 'left')
                        ->orderBy('hasil_wp.nilai_v', 'DESC')
                        ->findAll(5);
        
        $graph_labels = [];
        $graph_values = [];

        if (!empty($rankingData) && $rankingData[0]['nilai_v'] !== null) {
            foreach ($rankingData as $row) {
                $graph_labels[] = $row['nama_karyawan'] ?? 'Tanpa Nama';
                $graph_values[] = (float)($row['nilai_v'] ?? 0);
            }
        } else {
            // Tampilan jika tabel hasil_wp kosong
            $graph_labels = ['Belum ada perhitungan'];
            $graph_values = [0];
        }

        $data = [
            'title'            => 'Dashboard Utama',
            'total_alternatif' => $total_alternatif,
            'total_kriteria'   => $total_kriteria,
            'log_terbaru'      => $this->logModel->orderBy('created_at', 'DESC')->findAll(5),
            'graph_labels'     => $graph_labels,
            'graph_values'     => $graph_values
        ];

        // 3. Logika pemisah view berdasarkan role
        if (session()->get('role') == 'manager') {
            return view('dashboard_manager', $data);
        }

        return view('dashboard', $data);
    }
}