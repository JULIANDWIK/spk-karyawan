<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        // Jika sudah login, langsung arahkan ke dashboard tanpa memandang role
        if (session()->get('logged_in')) {
            return redirect()->to(base_url('dashboard'));
        }
        return view('auth/login');
    }

    public function proses_login()
    {
        $model = new UserModel();
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $model->where('username', $username)->first();

        if ($user) {
            // Cek kecocokan password
            if (password_verify($password, $user['password'])) {
                $sessionData = [
                    'id_user'      => $user['id_user'],
                    'username'     => $user['username'],
                    'nama_lengkap' => $user['nama_lengkap'],
                    'role'         => $user['role'],
                    'logged_in'    => TRUE
                ];
                session()->set($sessionData);

                // PERBAIKAN: Semua role (Admin maupun Manager) diarahkan ke Dashboard
                return redirect()->to(base_url('dashboard'))->with('success', 'Selamat datang kembali, ' . $user['username']);

            } else {
                return redirect()->back()->with('error', 'Password salah!');
            }
        } else {
            return redirect()->back()->with('error', 'Username tidak ditemukan!');
        }
    }

    public function logout()
    {
        // Hapus semua data session
        session()->destroy();
        
        // Redirect ke halaman login utama
        return redirect()->to(base_url('login'))->with('success', 'Berhasil keluar sistem.');
    }
}