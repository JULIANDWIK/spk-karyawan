<?php

namespace App\Controllers;

use App\Models\KriteriaModel;
use App\Models\LogModel;

class Kriteria extends BaseController
{
    protected $kritModel, $logModel;

    public function __construct()
    {
        $this->kritModel = new KriteriaModel();
        $this->logModel = new LogModel();
    }

    // Menampilkan daftar kriteria
    public function index()
    {
        $data = [
            'title'    => 'Manajemen Kriteria WP',
            'kriteria' => $this->kritModel->findAll(),
        ];

        return view('kriteria/index', $data);
    }

    // Menampilkan form tambah
    public function tambah()
    {
        $data = ['title' => 'Tambah Kriteria'];
        return view('kriteria/tambah', $data);
    }

    // Proses Tambah Kriteria
    public function simpan()
    {
        $this->kritModel->save([
            'nama_kriteria' => $this->request->getPost('nama_kriteria'),
            'bobot'         => $this->request->getPost('bobot'),
            'tipe'          => $this->request->getPost('tipe'), 
        ]);

        $nama = $this->request->getPost('nama_kriteria');
        $this->logModel->simpanLog("Tambah Kriteria", "Menambah kriteria baru: $nama");

        return redirect()->to(base_url('kriteria'))->with('success', 'Kriteria berhasil ditambahkan.');
    }

    // Menampilkan form edit
    public function edit($id)
    {
        $data = [
            'title'    => 'Edit Kriteria',
            'kriteria' => $this->kritModel->find($id)
        ];

        // Cek jika data tidak ditemukan
        if (!$data['kriteria']) {
            return redirect()->to(base_url('kriteria'))->with('error', 'Data kriteria tidak ditemukan.');
        }

        // Memastikan file view adalah 'kriteria/edit'
        return view('kriteria/edit', $data);
    }

    // Proses Update Kriteria
    public function update($id)
    {
        // Pastikan nama input di getPost sama dengan yang ada di file view edit.php
        $this->kritModel->update($id, [
            'nama_kriteria' => $this->request->getPost('nama_kriteria'),
            'bobot'         => $this->request->getPost('bobot'),
            'tipe'          => $this->request->getPost('tipe'),
        ]);

        $this->logModel->simpanLog("Update Kriteria", "Mengubah data kriteria ID: $id");

        return redirect()->to(base_url('kriteria'))->with('success', 'Kriteria berhasil diperbarui.');
    }

    // Proses Hapus Kriteria
    public function hapus($id)
    {
        $this->kritModel->delete($id);
        $this->logModel->simpanLog("Hapus Kriteria", "Menghapus kriteria ID: $id");

        return redirect()->to(base_url('kriteria'))->with('success', 'Kriteria berhasil dihapus.');
    }
}