<?php

namespace App\Controllers;

use App\Models\KriteriaModel;
use App\Models\AlternatifModel;
use App\Models\PenilaianModel;

class Hasil extends BaseController
{
    public function index()
    {
        $kritModel = new KriteriaModel();
        $altModel  = new AlternatifModel();
        $penModel  = new PenilaianModel();

        $kriteria   = $kritModel->findAll();
        $alternatif = $altModel->findAll();
        $penilaian  = $penModel->findAll();

        // Jika data penilaian masih kosong, tampilkan halaman kosong
        if (empty($penilaian)) {
            return view('hasil/index', [
                'title'   => 'Hasil Peringkat WP',
                'ranking' => []
            ]);
        }

        // 1. Hitung Total Bobot untuk Normalisasi
        $totalBobot = array_sum(array_column($kriteria, 'bobot'));

        // 2. Hitung Vektor S
        $data_s = [];
        $total_vektor_s = 0;

        foreach ($alternatif as $alt) {
            $s = 1;
            foreach ($kriteria as $k) {
                // Ambil nilai dari tabel penilaian
                $nilaiRow = $penModel->where([
                    'id_alternatif' => $alt['id_alternatif'],
                    'id_kriteria'   => $k['id_kriteria']
                ])->first();

                // Gunakan nilai 1 jika data tidak ada agar tidak merusak perkalian
                $nilai = ($nilaiRow && $nilaiRow['nilai'] > 0) ? $nilaiRow['nilai'] : 1;
                
                // Normalisasi Bobot: benefit (+), cost (-)
                $wj = ($k['tipe'] == 'benefit') ? ($k['bobot'] / $totalBobot) : -($k['bobot'] / $totalBobot);
                
                // Rumus Vektor S: Nilai dipangkatkan Bobot Normalisasi
                $s *= pow($nilai, $wj);
            }

            $data_s[$alt['id_alternatif']] = [
                'nama_karyawan' => $alt['nama_karyawan'],
                'posisi'        => $alt['posisi'], // Sudah diganti dari jabatan ke posisi
                'vektor_s'      => $s
            ];
            $total_vektor_s += $s;
        }

        // 3. Hitung Vektor V (Skor Akhir Preferensi)
        $ranking = [];
        foreach ($data_s as $id_alt => $val) {
            $v = ($total_vektor_s != 0) ? ($val['vektor_s'] / $total_vektor_s) : 0;
            $ranking[] = [
                'nama_karyawan' => $val['nama_karyawan'],
                'posisi'        => $val['posisi'],
                'nilai_v'       => $v
            ];
        }

        // 4. Urutkan berdasarkan Nilai V tertinggi (Ranking)
        usort($ranking, function ($a, $b) {
            return $b['nilai_v'] <=> $a['nilai_v'];
        });

        return view('hasil/index', [
            'title'   => 'Hasil Peringkat WP',
            'ranking' => $ranking
        ]);
    }
}