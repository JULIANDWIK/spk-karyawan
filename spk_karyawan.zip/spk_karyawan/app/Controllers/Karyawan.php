<?php 

namespace App\Controllers;

use App\Models\AlternatifModel;
use App\Models\LogModel;

class Karyawan extends BaseController {
    
    protected $altModel, $logModel;

    public function __construct() {
        $this->altModel = new AlternatifModel();
        $this->logModel = new LogModel();
    }

    // Menampilkan daftar karyawan (Alternatif)
    public function index() {
        $data = [
            'title'    => 'Data Karyawan',
            'karyawan' => $this->altModel->findAll()
        ];
        // Pastikan folder di Views bernama 'alternatif'
        return view('alternatif/index', $data);
    }

    // Menampilkan form tambah karyawan
    public function tambah_alternatif() {
        $data = [
            'title' => 'Tambah Karyawan Baru'
        ];
        return view('alternatif/tambah', $data);
    }

    // Memproses penyimpanan data (Insert)
    public function simpan_alternatif() {
        $nama   = $this->request->getPost('nama_karyawan');
        $posisi = $this->request->getPost('posisi');

        // Validasi sederhana agar tidak menyimpan data kosong
        if (empty($nama) || empty($posisi)) {
            return redirect()->back()->with('error', 'Nama dan Jabatan harus diisi!');
        }

        $this->altModel->save([
            'nama_karyawan' => $nama,
            'posisi'        => $posisi, // Sinkron dengan kolom database 'posisi'
        ]);
        
        $this->logModel->simpanLog("Tambah Karyawan", "Menambah karyawan baru: " . $nama);
        
        return redirect()->to(base_url('karyawan'))->with('success', 'Data karyawan berhasil disimpan.');
    }

    // Menghapus data karyawan
    public function hapus_alternatif($id) {
        $this->altModel->delete($id);
        $this->logModel->simpanLog("Hapus Karyawan", "Menghapus ID Karyawan: " . $id);
        
        return redirect()->to(base_url('karyawan'))->with('success', 'Karyawan berhasil dihapus.');
    }

    // Tambahan: Method Edit agar tidak error saat klik tombol edit di view
    public function edit_alternatif($id) {
        $data = [
            'title' => 'Edit Data Karyawan',
            'karyawan' => $this->altModel->find($id)
        ];
        
        if (!$data['karyawan']) {
            return redirect()->to(base_url('karyawan'))->with('error', 'Data tidak ditemukan.');
        }

        return view('alternatif/edit', $data);
    }
}