<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h3 class="fw-extrabold text-dark mb-1" style="letter-spacing: -1px;">Manajemen Karyawan</h3>
            <p class="text-muted small mb-0">Kelola daftar alternatif karyawan yang akan diproses dalam sistem Weighted Product.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= base_url('karyawan/tambah') ?>" class="btn btn-primary shadow-primary rounded-3 px-4 hover-lift">
                <i class="bi bi-person-plus-fill me-2"></i>Tambah Karyawan
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
        <div class="card-header bg-white py-3 px-4 border-bottom border-light d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <i class="bi bi-filter-left fs-4 me-2 text-primary"></i>
                <span class="fw-bold text-dark">Daftar Alternatif</span>
            </div>
            <div class="input-group input-group-sm" style="width: 250px;">
                <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                <input type="text" class="form-control bg-light border-0" placeholder="Cari karyawan...">
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem; width: 60px;">No</th>
                            <th class="py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem;">Informasi Karyawan</th>
                            <th class="py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem;">Posisi / Jabatan</th>
                            <th class="py-3 text-uppercase text-muted fw-bold text-center" style="font-size: 0.65rem; width: 180px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($alternatif)) : ?>
                            <?php $no = 1; foreach($alternatif as $k) : ?>
                            <tr class="transition-all">
                                <td class="ps-4">
                                    <span class="text-muted fw-medium small"><?= str_pad($no++, 2, '0', STR_PAD_LEFT) ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-pill me-3 shadow-sm">
                                            <?= strtoupper(substr($k['nama_karyawan'] ?? 'K', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark mb-0"><?= $k['nama_karyawan'] ?></div>
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-light text-muted fw-normal border" style="font-size: 0.6rem;">ID: #ALT-<?= str_pad($k['id_alternatif'], 3, '0', STR_PAD_LEFT) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-inline-flex align-items-center py-1 px-3 bg-primary-soft rounded-pill border border-primary-subtle shadow-sm">
                                        <i class="bi bi-briefcase-fill text-primary me-2" style="font-size: 0.8rem;"></i>
                                        <span class="text-primary fw-bold" style="font-size: 0.75rem;"><?= $k['posisi'] ?></span>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="<?= base_url('karyawan/edit/'.$k['id_alternatif']) ?>" class="btn btn-icon btn-light hover-primary" title="Edit Data">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="<?= base_url('karyawan/hapus/'.$k['id_alternatif']) ?>" 
                                           class="btn btn-icon btn-light hover-danger" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus karyawan ini? Semua data penilaian terkait juga akan hilang.')"
                                           title="Hapus Data">
                                             <i class="bi bi-trash3"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="4" class="text-center py-5">
                                    <div class="py-4 opacity-50">
                                        <img src="https://illustrations.popsy.co/blue/abstract-art-4.svg" style="width: 150px;" class="mb-3">
                                        <h6 class="fw-bold text-dark">Data Kosong</h6>
                                        <p class="text-muted small">Belum ada karyawan terdaftar dalam sistem.</p>
                                        <a href="<?= base_url('karyawan/tambah') ?>" class="btn btn-sm btn-primary rounded-pill px-4 shadow-primary mt-2">Tambah Sekarang</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-3 px-4 border-top border-light">
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">Menampilkan <strong><?= count($alternatif ?? []) ?></strong> karyawan</small>
                <nav>
                    <ul class="pagination pagination-sm mb-0">
                        <li class="page-item disabled"><a class="page-link border-0" href="#">Prev</a></li>
                        <li class="page-item active"><a class="page-link rounded-circle mx-1 border-0 shadow-sm" href="#">1</a></li>
                        <li class="page-item disabled"><a class="page-link border-0" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<style>
    /* Styling Dasar */
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background-color: rgba(99, 102, 241, 0.08) !important; }
    .shadow-primary { box-shadow: 0 8px 15px rgba(99, 102, 241, 0.25) !important; }
    
    /* Avatar Pill Style */
    .avatar-pill {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #6366f1, #a855f7);
        color: white;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
    }

    /* Table Enhancements */
    .table thead th {
        background-color: #fcfcfd;
        border-bottom: 1px solid #f1f5f9;
        letter-spacing: 0.05em;
    }
    
    .table tbody tr {
        transition: all 0.2s ease;
    }
    
    .table tbody tr:hover {
        background-color: #f8fafc !important;
        transform: scale(1.002);
    }

    /* Custom Buttons */
    .btn-icon {
        width: 34px;
        height: 34px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        transition: all 0.2s ease;
        border: none;
    }

    .btn-white {
        background-color: #fff;
        color: #64748b;
        font-weight: 600;
        font-size: 0.85rem;
    }

    .hover-primary:hover {
        background-color: #6366f1 !important;
        color: white !important;
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }

    .hover-danger:hover {
        background-color: #ef4444 !important;
        color: white !important;
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
    }

    .hover-lift:hover {
        transform: translateY(-2px);
    }

    .transition-all { transition: all 0.3s ease; }
</style>
<?= $this->endSection() ?>