<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center py-4">
    <div class="col-lg-5 col-md-8">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb bg-transparent p-0 mb-0">
                <li class="breadcrumb-item small"><a href="<?= base_url('alternatif') ?>" class="text-decoration-none text-muted">Manajemen Karyawan</a></li>
                <li class="breadcrumb-item active small fw-bold text-primary" aria-current="page">Perbarui Data</li>
            </ol>
        </nav>

        <div class="card border-0 shadow-sm overflow-hidden" style="border-radius: 24px; background: #ffffff;">
            <div class="card-header bg-white py-4 border-0">
                <div class="d-flex align-items-center px-2">
                    <div class="icon-box-status bg-warning-soft text-warning me-3 shadow-sm">
                        <i class="bi bi-pencil-square"></i>
                    </div>
                    <div>
                        <h5 class="mb-1 fw-extrabold text-dark" style="letter-spacing: -0.5px;">Edit Informasi</h5>
                        <p class="text-muted small mb-0">Sesuaikan detail alternatif karyawan yang terpilih.</p>
                    </div>
                </div>
            </div>
            
            <div class="card-body p-4 pt-0">
                <form action="<?= base_url('alternatif/update/' . $alternatif['id_alternatif']) ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Nama Lengkap Karyawan</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-person text-primary"></i>
                            </span>
                            <input type="text" 
                                   name="nama_karyawan" 
                                   class="form-control-modern" 
                                   value="<?= old('nama_karyawan', $alternatif['nama_karyawan']) ?>" 
                                   placeholder="Contoh: Budi Santoso" 
                                   required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Posisi / Jabatan</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-briefcase text-primary"></i>
                            </span>
                            <input type="text" 
                                   name="posisi" 
                                   class="form-control-modern" 
                                   value="<?= old('posisi', $alternatif['posisi']) ?>" 
                                   placeholder="Contoh: Senior Staff" 
                                   required>
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2 mt-4">
                        <button type="submit" class="btn btn-primary py-3 fw-bold rounded-4 shadow-primary hover-lift">
                            <i class="bi bi-arrow-repeat me-2"></i>Simpan Perubahan
                        </button>
                        <a href="<?= base_url('alternatif') ?>" class="btn btn-light py-3 fw-semibold rounded-4 text-muted border-0">
                            Batalkan
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="text-center mt-4">
            <p class="text-muted small">ID Alternatif: <span class="fw-bold">#ALT-<?= str_pad($alternatif['id_alternatif'], 3, '0', STR_PAD_LEFT) ?></span></p>
        </div>
    </div>
</div>

<style>
    /* Global Helpers */
    .fw-extrabold { font-weight: 800; }
    .bg-warning-soft { background: rgba(245, 158, 11, 0.1); }
    .shadow-primary { box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2) !important; }

    /* Icon Box */
    .icon-box-status {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }

    /* Modern Input Control */
    .input-group-modern {
        position: relative;
        display: flex;
        align-items: center;
        background: #f1f5f9;
        border-radius: 16px;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .input-icon {
        padding-left: 18px;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
    }

    .form-control-modern {
        background: transparent;
        border: none;
        padding: 14px 18px;
        width: 100%;
        color: #1e293b;
        font-weight: 500;
        outline: none;
    }

    .input-group-modern:focus-within {
        background: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 10px 25px rgba(79, 70, 229, 0.08);
    }

    /* Hover Lift */
    .hover-lift {
        transition: all 0.2s ease;
    }
    .hover-lift:hover {
        transform: translateY(-3px);
        opacity: 0.95;
    }

    /* Animation */
    .row {
        animation: slideUp 0.4s ease-out;
    }

    @keyframes slideUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?= $this->endSection() ?>