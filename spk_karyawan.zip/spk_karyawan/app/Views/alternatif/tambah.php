<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center py-4">
    <div class="col-lg-5 col-md-8">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb bg-transparent p-0 mb-0">
                <li class="breadcrumb-item small"><a href="<?= base_url('alternatif') ?>" class="text-decoration-none text-muted">Manajemen Karyawan</a></li>
                <li class="breadcrumb-item active small fw-bold text-primary" aria-current="page">Registrasi Baru</li>
            </ol>
        </nav>

        <div class="card border-0 shadow-sm overflow-hidden" style="border-radius: 24px; background: #ffffff;">
            <div class="card-header bg-white py-4 border-0">
                <div class="d-flex align-items-center px-2">
                    <div class="icon-box-status bg-primary-soft text-primary me-3 shadow-sm">
                        <i class="bi bi-person-plus-fill"></i>
                    </div>
                    <div>
                        <h5 class="mb-1 fw-extrabold text-dark" style="letter-spacing: -0.5px;">Registrasi Karyawan</h5>
                        <p class="text-muted small mb-0">Input detail kandidat untuk proses seleksi.</p>
                    </div>
                </div>
            </div>
            
            <div class="card-body p-4 pt-0">
                <form action="<?= base_url('alternatif/simpan') ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Nama Lengkap</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-person text-primary"></i>
                            </span>
                            <input type="text" name="nama_karyawan" 
                                   class="form-control-modern" 
                                   placeholder="Contoh: Budi Santoso, S.Kom" required autofocus>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Posisi / Jabatan</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-briefcase text-primary"></i>
                            </span>
                            <input type="text" name="posisi" 
                                   class="form-control-modern" 
                                   placeholder="Contoh: Senior Web Developer" required>
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2 mt-4">
                        <button type="submit" class="btn btn-primary py-3 fw-bold rounded-4 shadow-primary hover-lift">
                            <i class="bi bi-cloud-arrow-up-fill me-2"></i>Simpan Data Karyawan
                        </button>
                        <a href="<?= base_url('alternatif') ?>" class="btn btn-light py-3 fw-semibold rounded-4 text-muted border-0">
                            Batalkan
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card border-0 mt-4 shadow-sm" style="border-radius: 18px; background-color: #f8fafc;">
            <div class="card-body p-3 d-flex align-items-center">
                <div class="rounded-circle bg-white p-2 shadow-sm me-3">
                    <i class="bi bi-lightbulb-fill text-warning"></i>
                </div>
                <small class="text-dark fw-medium">
                    Data yang disimpan akan langsung tersedia di menu <span class="text-primary fw-bold">Penilaian</span>.
                </small>
            </div>
        </div>
    </div>
</div>

<style>
    /* Styling Dasar & Variabel */
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background: rgba(79, 70, 229, 0.1); }
    .shadow-primary { box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2) !important; }

    /* Custom Icon Box */
    .icon-box-status {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }

    /* Modern Input Style */
    .input-group-modern {
        position: relative;
        display: flex;
        align-items: center;
        background: #f1f5f9;
        border-radius: 16px;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .input-icon {
        padding-left: 18px;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
    }

    .form-control-modern {
        background: transparent;
        border: none;
        padding: 14px 18px;
        width: 100%;
        color: #1e293b;
        font-weight: 500;
        outline: none;
    }

    .form-control-modern::placeholder {
        color: #94a3b8;
        font-weight: 400;
    }

    .input-group-modern:focus-within {
        background: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 10px 25px rgba(79, 70, 229, 0.08);
    }

    /* Hover Effects */
    .hover-lift {
        transition: all 0.2s ease;
    }
    .hover-lift:hover {
        transform: translateY(-3px);
        opacity: 0.95;
    }

    /* Animasi muncul (fade in) */
    .row {
        animation: fadeIn 0.5s ease-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?= $this->endSection() ?>