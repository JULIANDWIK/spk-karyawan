<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0">
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 rounded-4 overflow-hidden shadow-sm" style="background: linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%);">
                <div class="card-body p-4 p-md-5">
                    <div class="row align-items-center">
                        <div class="col-lg-8 text-center text-lg-start">
                            <span class="badge bg-primary-soft text-primary px-3 py-2 rounded-pill mb-3 fw-bold">
                                <i class="bi bi-stars me-1"></i> WP Analysis Version 2.0
                            </span>
                            <h1 class="display-5 fw-extrabold text-dark mb-2" style="letter-spacing: -1px;">
                                Selamat Datang, <span class="text-primary"><?= session()->get('nama_lengkap') ?? 'Administrator' ?></span>!
                            </h1>
                            <p class="lead text-muted mb-4 pe-lg-5">Optimalkan keputusan SDM dengan presisi menggunakan metode <span class="fw-bold text-dark">Weighted Product (WP)</span> yang objektif dan transparan.</p>
                            
                            <div class="d-flex flex-wrap gap-3 justify-content-center justify-content-lg-start">
                                <a href="<?= base_url('penilaian') ?>" class="btn btn-primary btn-lg rounded-3 px-4 shadow hover-lift">
                                    <i class="bi bi-lightning-charge-fill me-2"></i>Mulai Kalkulasi
                                </a>
                                <a href="<?= base_url('kriteria') ?>" class="btn btn-outline-secondary btn-lg rounded-3 px-4 hover-lift bg-white">
                                    <i class="bi bi-gear-wide-connected me-2"></i>Parameter
                                </a>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 transition-all hover-up">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="icon-shape-lg bg-primary text-white rounded-3 shadow-primary">
                            <i class="bi bi-people-fill fs-4"></i>
                        </div>
                        <div class="text-end">
                            <p class="text-uppercase text-muted fw-bold mb-0 small tracking-widest">Alternatif</p>
                            <h2 class="fw-extrabold mb-0"><?= $total_alternatif ?? '0' ?></h2>
                        </div>
                    </div>
                    <div class="pt-3 border-top mt-3">
                        <span class="text-success small fw-bold"><i class="bi bi-check2-all me-1"></i>Total Karyawan Terdaftar</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 transition-all hover-up">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="icon-shape-lg bg-info text-white rounded-3 shadow-info">
                            <i class="bi bi-layers-half fs-4"></i>
                        </div>
                        <div class="text-end">
                            <p class="text-uppercase text-muted fw-bold mb-0 small tracking-widest">Kriteria</p>
                            <h2 class="fw-extrabold mb-0"><?= $total_kriteria ?? '0' ?></h2>
                        </div>
                    </div>
                    <div class="pt-3 border-top mt-3">
                        <span class="text-info small fw-bold"><i class="bi bi-info-circle me-1"></i>Indikator Penilaian</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 transition-all hover-up bg-white">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="icon-shape-lg bg-success text-white rounded-3 shadow-success">
                            <i class="bi bi-shield-lock-fill fs-4"></i>
                        </div>
                        <div class="text-end text-dark">
                            <p class="text-uppercase text-muted fw-bold mb-0 small tracking-widest">System Status</p>
                            <h2 class="fw-extrabold mb-0">Secure</h2>
                        </div>
                    </div>
                    <div class="d-flex align-items-center pt-3 border-top mt-3">
                        <div class="pulsating-circle me-2"></div>
                        <span class="text-dark small fw-bold">Sistem Berjalan Normal</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div class="card-header bg-white py-4 px-4 border-0 d-flex align-items-center justify-content-between">
                    <div>
                        <h5 class="fw-bold mb-1 text-dark">Log Aktivitas Terbaru</h5>
                        <p class="text-muted small mb-0">Monitoring audit sistem secara real-time</p>
                    </div>
                    <button class="btn btn-light btn-sm rounded-3">Lihat Semua</button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light border-bottom border-top">
                                <tr>
                                    <th class="ps-4 py-3 text-dark fw-bold small">WAKTU</th>
                                    <th class="py-3 text-dark fw-bold small text-center">AKSI</th>
                                    <th class="py-3 text-dark fw-bold small">KETERANGAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($log_terbaru)): ?>
                                    <?php foreach ($log_terbaru as $log): ?>
                                    <tr>
                                        <td class="ps-4 small text-muted fw-medium">
                                            <?= date('d/m/Y', strtotime($log['created_at'])) ?> <span class="opacity-50 ms-1"><?= date('H:i', strtotime($log['created_at'])) ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-primary-soft text-primary px-3 py-2 rounded-pill fw-bold" style="font-size: 10px;">
                                                <?= strtoupper($log['aktivitas']) ?>
                                            </span>
                                        </td>
                                        <td class="small text-secondary fw-medium"><?= $log['keterangan'] ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-5">
                                            <img src="https://illustrations.popsy.co/blue/waiting.svg" style="width: 120px;" class="mb-3 opacity-25">
                                            <p class="text-muted small fw-bold">Belum ada riwayat aktivitas sistem.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card border-0 bg-sidebar-dark rounded-4 shadow-lg text-white h-100 overflow-hidden" style="background-color: #0b0f1a;">
                <div class="card-body p-4 position-relative">
                    <div class="position-absolute top-0 end-0 p-3 opacity-10">
                        <i class="bi bi-info-circle-fill display-1"></i>
                    </div>

                    <h5 class="fw-bold mb-4 text-primary"><i class="bi bi-lightbulb-fill me-2"></i>Knowledge Center</h5>
                    <p class="small text-white-50 lh-lg mb-4">
                        Metode <strong class="text-white">Weighted Product</strong> menyeleksi alternatif terbaik dengan cara perkalian (produk) rating atribut, di mana setiap rating dipangkatkan dengan bobot kepentingan.
                    </p>
                    
                    <div class="p-3 bg-white bg-opacity-10 rounded-4 border border-white border-opacity-10 mb-4">
                        <p class="mb-0 small fw-medium text-white italic">
                            <i class="bi bi-quote fs-4 d-block mb-1 opacity-50"></i>
                            "WP memastikan kriteria dengan bobot lebih tinggi memiliki pengaruh pangkat yang lebih dominan dalam menentukan hasil akhir."
                        </p>
                    </div>

                    <div class="d-grid gap-2">
                        <div class="d-flex align-items-center small mb-2">
                            <i class="bi bi-check-circle-fill text-primary me-3"></i>
                            <span>Skalabilitas perhitungan tinggi</span>
                        </div>
                        <div class="d-flex align-items-center small mb-2">
                            <i class="bi bi-check-circle-fill text-primary me-3"></i>
                            <span>Sensitivitas terhadap bobot akurat</span>
                        </div>
                        <div class="d-flex align-items-center small">
                            <i class="bi bi-check-circle-fill text-primary me-3"></i>
                            <span>Hasil perankingan objektif</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Global Content Enhancements */
    .fw-extrabold { font-weight: 800; }
    .tracking-widest { letter-spacing: 0.1em; }
    .bg-primary-soft { background: rgba(99, 102, 241, 0.12); }
    
    /* Icon Boxes */
    .icon-shape-lg {
        width: 56px;
        height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .shadow-primary { box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3); }
    .shadow-info { box-shadow: 0 8px 20px rgba(6, 182, 212, 0.3); }
    .shadow-success { box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3); }

    /* Animations & Hover */
    .hover-up:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.1) !important;
    }
    
    .hover-lift:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.1);
    }

    .floating-animation {
        animation: floating 4s ease-in-out infinite;
    }

    @keyframes floating {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-15px); }
    }

    /* Status Pulse */
    .pulsating-circle {
        width: 10px;
        height: 10px;
        background-color: #10b981;
        border-radius: 50%;
        position: relative;
    }
    .pulsating-circle::after {
        content: "";
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: #10b981;
        border-radius: 50%;
        animation: pulse-ring 1.5s cubic-bezier(0.455, 0.03, 0.515, 0.955) infinite;
    }

    @keyframes pulse-ring {
        0% { transform: scale(0.3); opacity: 1; }
        80%, 100% { transform: scale(2.5); opacity: 0; }
    }

    .transition-all { transition: all 0.3s ease; }
</style>

<?= $this->endSection() ?>