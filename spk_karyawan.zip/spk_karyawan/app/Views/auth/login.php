<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Login | SPK Performa</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --primary: #4f46e5;
            --slate-900: #0f172a;
        }

        @keyframes ultra-glow {
            0% { box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7); }
            50% { 
                box-shadow: 0 0 50px 15px rgba(79, 70, 229, 0.8), 
                            0 0 100px 30px rgba(79, 70, 229, 0.4), 
                            0 25px 50px -12px rgba(0, 0, 0, 0.7); 
            }
            100% { box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7); }
        }

        body {
            background-image: linear-gradient(rgba(15, 23, 42, 0.85), rgba(15, 23, 42, 0.85)), 
                              url('https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1600');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', sans-serif;
            margin: 0;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 28px;
            padding: 3rem 2.75rem;
            border: 1px solid rgba(255, 255, 255, 0.4);
            animation: ultra-glow 3s infinite ease-in-out;
            transition: transform 0.3s ease;
            position: relative;
            z-index: 1;
        }

        .brand-logo {
            width: 60px; height: 60px;
            background: var(--slate-900);
            color: white;
            border-radius: 16px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.8rem; margin-bottom: 1.5rem;
        }

        h3 { font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800; color: var(--slate-900); }
        .subtitle { color: #64748b; font-size: 0.925rem; margin-bottom: 2.5rem; }
        .form-label { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #1e293b; margin-bottom: 0.6rem; }

        .input-group {
            background-color: #f8fafc;
            border: 1.5px solid #e2e8f0;
            border-radius: 12px;
            transition: all 0.2s ease;
        }

        .input-group:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        .input-group-text { background: transparent; border: none; color: #64748b; padding-left: 1.25rem; }
        .form-control { background: transparent; border: none; padding: 0.75rem 1.25rem 0.75rem 0.5rem; font-size: 0.95rem; }
        .form-control:focus { box-shadow: none; }

        .btn-login {
            background: var(--slate-900);
            color: white; border: none; padding: 1rem; border-radius: 12px;
            font-weight: 700; margin-top: 1rem; transition: all 0.3s ease;
            display: flex; align-items: center; justify-content: center; gap: 10px;
        }

        .btn-login:hover { background: var(--primary); box-shadow: 0 10px 25px rgba(79, 70, 229, 0.4); }
        .footer-text { margin-top: 2.5rem; font-size: 0.75rem; color: #64748b; text-align: center; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="brand-logo">
        <i class="bi bi-building-fill"></i>
    </div>

    <h3>Sign In</h3>
    <p class="subtitle">Enterprise Resource Planning System</p>

    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger border-0 small rounded-3 mb-4 d-flex align-items-center">
            <i class="bi bi-exclamation-circle-fill me-2"></i>
            <div><?= session()->getFlashdata('error') ?></div>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('auth/proses_login') ?>" method="POST" autocomplete="off">
        <?= csrf_field() ?>
        
        <div class="mb-3">
            <label class="form-label">Username</label>
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                <input type="text" name="username" class="form-control" placeholder="ID Karyawan" 
                       value="" required autofocus autocomplete="off">
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">Password</label>
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-shield-lock-fill"></i></span>
                <input type="password" name="password" class="form-control" placeholder="••••••••" 
                       value="" required autocomplete="new-password">
            </div>
        </div>

        <button type="submit" class="btn btn-login w-100">
            Sign to Dashboard
            <i class="bi bi-arrow-right-short fs-4"></i>
        </button>
    </form>

    <div class="footer-text">
        &copy; 2026 PT. JULIET <br>
        <span class="opacity-75">Decision Support System - WP Method</span>
    </div>
</div>

</body>
</html>