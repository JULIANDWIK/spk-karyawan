<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center py-4">
    <div class="col-lg-5 col-md-8">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb bg-transparent p-0 mb-0">
                <li class="breadcrumb-item small"><a href="<?= base_url('kriteria') ?>" class="text-decoration-none text-muted">Data Kriteria</a></li>
                <li class="breadcrumb-item active small fw-bold text-primary" aria-current="page">Perbarui Kriteria</li>
            </ol>
        </nav>

        <div class="card border-0 shadow-sm overflow-hidden" style="border-radius: 24px; background: #ffffff;">
            <div class="card-header bg-white py-4 border-0">
                <div class="d-flex align-items-center px-2">
                    <div class="icon-box-status bg-warning-soft text-warning me-3 shadow-sm">
                        <i class="bi bi-pencil-square"></i>
                    </div>
                    <div>
                        <h5 class="mb-1 fw-extrabold text-dark" style="letter-spacing: -0.5px;">Edit Kriteria</h5>
                        <p class="text-muted small mb-0">Sesuaikan parameter kriteria #CRT-<?= $kriteria['id_kriteria'] ?></p>
                    </div>
                </div>
            </div>
            
            <div class="card-body p-4 pt-0">
                <form action="<?= base_url('kriteria/update/' . $kriteria['id_kriteria']) ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Nama Kriteria</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-tag text-warning"></i>
                            </span>
                            <input type="text" 
                                   name="nama_kriteria" 
                                   class="form-control-modern" 
                                   value="<?= old('nama_kriteria', $kriteria['nama_kriteria']) ?>" 
                                   placeholder="Misal: Kedisiplinan" 
                                   required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Bobot Kriteria</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-award text-warning"></i>
                            </span>
                            <input type="number" 
                                   step="0.01" 
                                   name="bobot" 
                                   class="form-control-modern" 
                                   value="<?= old('bobot', $kriteria['bobot']) ?>" 
                                   placeholder="Contoh: 5" 
                                   required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Tipe Kriteria</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-arrow-down-up text-warning"></i>
                            </span>
                            <select name="tipe" class="form-control-modern pe-4" style="cursor: pointer;" required>
                                <option value="benefit" <?= (old('tipe', $kriteria['tipe']) == 'benefit' ? 'selected' : '') ?>>Benefit (Nilai tinggi = makin baik)</option>
                                <option value="cost" <?= (old('tipe', $kriteria['tipe']) == 'cost' ? 'selected' : '') ?>>Cost (Nilai rendah = makin baik)</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2 mt-4 pt-2 border-top">
                        <button type="submit" class="btn btn-warning py-3 fw-bold rounded-4 shadow-warning hover-lift text-white mt-2">
                            <i class="bi bi-arrow-repeat me-2"></i>Perbarui Data
                        </button>
                        <a href="<?= base_url('kriteria') ?>" class="btn btn-light py-3 fw-semibold rounded-4 text-muted border-0 text-center">
                            Batalkan
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="text-center mt-4">
            <p class="text-muted small">Terakhir diperbarui: <span class="fw-bold"><?= date('d M Y') ?></span></p>
        </div>
    </div>
</div>

<style>
    /* Styling Global */
    .fw-extrabold { font-weight: 800; }
    .bg-warning-soft { background: rgba(245, 158, 11, 0.1); }
    .shadow-warning { box-shadow: 0 10px 20px rgba(245, 158, 11, 0.2) !important; }

    /* Icon Box */
    .icon-box-status {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }

    /* Modern Input Control */
    .input-group-modern {
        position: relative;
        display: flex;
        align-items: center;
        background: #f8fafc;
        border-radius: 16px;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .input-icon {
        padding-left: 18px;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
    }

    .form-control-modern {
        background: transparent;
        border: none;
        padding: 14px 18px;
        width: 100%;
        color: #1e293b;
        font-weight: 500;
        outline: none;
        appearance: none;
    }

    .input-group-modern:focus-within {
        background: #ffffff;
        border-color: #f59e0b; /* Warna Warning */
        box-shadow: 0 10px 25px rgba(245, 158, 11, 0.08);
    }

    /* Hover Lift Effect */
    .hover-lift {
        transition: all 0.2s ease;
    }
    .hover-lift:hover {
        transform: translateY(-3px);
        opacity: 0.95;
    }

    /* Animation Entry */
    .row {
        animation: slideUp 0.4s ease-out;
    }

    @keyframes slideUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?= $this->endSection() ?>