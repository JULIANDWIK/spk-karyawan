<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h3 class="fw-extrabold text-dark mb-1" style="letter-spacing: -1px;">Kriteria Penilaian</h3>
            <p class="text-muted small mb-0">Atur bobot dan parameter kriteria untuk perhitungan algoritma Weighted Product.</p>
        </div>
        <a href="<?= base_url('kriteria/tambah') ?>" class="btn btn-primary shadow-primary rounded-3 px-4 hover-lift">
            <i class="bi bi-plus-circle-fill me-2"></i>Tambah Kriteria
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4 py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem; width: 70px;">No</th>
                            <th class="py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem;">Nama Kriteria</th>
                            <th class="py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem; width: 280px;">Bobot Kepentingan</th>
                            <th class="py-3 text-uppercase text-muted fw-bold" style="font-size: 0.65rem; width: 150px;">Tipe</th>
                            <th class="py-3 text-uppercase text-muted fw-bold text-center" style="font-size: 0.65rem; width: 140px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($kriteria)) : ?>
                            <?php $no = 1; foreach($kriteria as $k) : ?>
                            <tr class="transition-all">
                                <td class="ps-4">
                                    <span class="text-muted small fw-medium"><?= str_pad($no++, 2, '0', STR_PAD_LEFT) ?></span>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark mb-0"><?= $k['nama_kriteria'] ?></div>
                                    <span class="badge bg-light text-muted fw-normal border" style="font-size: 0.6rem;">ID: CRT-<?= $k['id_kriteria'] ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1 shadow-none" style="height: 10px; border-radius: 20px; background-color: #f1f5f9;">
                                            <?php 
                                                $percent = ($k['bobot'] <= 5) ? ($k['bobot'] / 5 * 100) : 100; 
                                            ?>
                                            <div class="progress-bar progress-bar-striped progress-bar-animated rounded-pill bg-primary-gradient" 
                                                 role="progressbar" 
                                                 style="width: <?= $percent ?>%;"></div>
                                        </div>
                                        <span class="ms-3 fw-extrabold text-primary" style="min-width: 25px;"><?= $k['bobot'] ?></span>
                                    </div>
                                </td>
                                <td>
                                    <?php if (strtolower($k['tipe']) == 'benefit') : ?>
                                        <div class="d-inline-flex align-items-center py-1 px-3 rounded-pill bg-success-soft border border-success-subtle shadow-sm">
                                            <span class="dot bg-success me-2"></span>
                                            <span class="text-success fw-bold small">BENEFIT</span>
                                        </div>
                                    <?php else : ?>
                                        <div class="d-inline-flex align-items-center py-1 px-3 rounded-pill bg-danger-soft border border-danger-subtle shadow-sm">
                                            <span class="dot bg-danger me-2"></span>
                                            <span class="text-danger fw-bold small">COST</span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="<?= base_url('kriteria/edit/' . $k['id_kriteria']) ?>" class="btn btn-icon btn-light hover-primary" title="Edit Kriteria">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="<?= base_url('kriteria/hapus/' . $k['id_kriteria']) ?>" 
                                           class="btn btn-icon btn-light hover-danger" 
                                           title="Hapus Kriteria" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus kriteria ini?')">
                                            <i class="bi bi-trash3"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <div class="py-4 opacity-50">
                                        <i class="bi bi-list-stars display-1 text-light"></i>
                                        <p class="text-muted mt-3">Belum ada kriteria yang dikonfigurasi.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mt-4 border-0 shadow-sm rounded-4 overflow-hidden" style="background: linear-gradient(to right, #ffffff, #f8fafc);">
        <div class="card-body p-4">
            <div class="row align-items-center">
                <div class="col-md-1 d-none d-md-block text-center">
                    <div class="icon-circle bg-primary-soft text-primary fs-3 shadow-sm">
                        <i class="bi bi-info-circle-fill"></i>
                    </div>
                </div>
                <div class="col-md-11 ps-md-4 border-start-md border-light">
                    <h6 class="fw-bold text-dark mb-2">Panduan Penentuan Tipe</h6>
                    <div class="row gy-2">
                        <div class="col-sm-6">
                            <div class="p-2 rounded-3 bg-white border border-light-subtle d-flex align-items-center shadow-sm">
                                <span class="badge bg-success-soft text-success me-3 py-2 px-2"><i class="bi bi-graph-up-arrow"></i></span>
                                <small class="text-muted"><strong class="text-success">Benefit:</strong> Kriteria yang nilainya diinginkan <strong>setinggi</strong> mungkin (cth: IPK, Pengalaman).</small>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="p-2 rounded-3 bg-white border border-light-subtle d-flex align-items-center shadow-sm">
                                <span class="badge bg-danger-soft text-danger me-3 py-2 px-2"><i class="bi bi-graph-down-arrow"></i></span>
                                <small class="text-muted"><strong class="text-danger">Cost:</strong> Kriteria yang nilainya diinginkan <strong>serendah</strong> mungkin (cth: Jarak, Gaji, Absensi).</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Styling Dasar */
    .fw-extrabold { font-weight: 800; }
    .shadow-primary { box-shadow: 0 8px 15px rgba(79, 70, 229, 0.25) !important; }
    .bg-primary-gradient { background: linear-gradient(90deg, #4f46e5, #818cf8) !important; }
    
    /* Soft Colors */
    .bg-success-soft { background-color: rgba(16, 185, 129, 0.1) !important; }
    .bg-danger-soft { background-color: rgba(239, 68, 68, 0.1) !important; }
    .bg-primary-soft { background-color: rgba(79, 70, 229, 0.1) !important; }

    /* Dot Indicator */
    .dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }

    /* Progress Bar Animation */
    .progress-bar-animated { animation: progress-bar-stripes 1s linear infinite; }

    /* Table Enhancements */
    .table thead th {
        background-color: #fcfcfd;
        border-bottom: 1px solid #f1f5f9;
        letter-spacing: 0.05em;
    }
    
    .table tbody tr:hover {
        background-color: #f8fafc !important;
    }

    /* Icon Box Helper */
    .icon-circle {
        width: 54px;
        height: 54px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Action Buttons */
    .btn-icon {
        width: 34px;
        height: 34px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        border: none;
        transition: all 0.2s;
    }

    .hover-primary:hover { background: #4f46e5 !important; color: white !important; }
    .hover-danger:hover { background: #ef4444 !important; color: white !important; }
    .hover-lift:hover { transform: translateY(-2px); }

    .transition-all { transition: all 0.2s ease; }
    
    @media (min-width: 768px) {
        .border-start-md { border-left: 1px solid #dee2e6 !important; }
    }
</style>
<?= $this->endSection() ?>