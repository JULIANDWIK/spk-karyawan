<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center py-4">
    <div class="col-lg-5 col-md-8">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb bg-transparent p-0 mb-0">
                <li class="breadcrumb-item small"><a href="<?= base_url('kriteria') ?>" class="text-decoration-none text-muted">Kriteria</a></li>
                <li class="breadcrumb-item active small fw-bold text-primary" aria-current="page">Konfigurasi Baru</li>
            </ol>
        </nav>

        <div class="card border-0 shadow-sm overflow-hidden" style="border-radius: 24px; background: #ffffff;">
            <div class="card-header bg-white py-4 border-0">
                <div class="d-flex align-items-center px-2">
                    <div class="icon-box-status bg-primary-soft text-primary me-3 shadow-sm">
                        <i class="bi bi-gear-wide-connected"></i>
                    </div>
                    <div>
                        <h5 class="mb-1 fw-extrabold text-dark" style="letter-spacing: -0.5px;">Konfigurasi Kriteria</h5>
                        <p class="text-muted small mb-0">Atur parameter penting untuk pembobotan WP.</p>
                    </div>
                </div>
            </div>
            
            <div class="card-body p-4 pt-0">
                <form action="<?= base_url('kriteria/simpan') ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Nama Kriteria</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-tag text-primary"></i>
                            </span>
                            <input type="text" name="nama_kriteria" 
                                   class="form-control-modern" 
                                   placeholder="Misal: Pengalaman Kerja" required autofocus>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Bobot Kepentingan</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-award text-primary"></i>
                            </span>
                            <input type="number" step="0.01" name="bobot" 
                                   class="form-control-modern" 
                                   placeholder="Nilai bobot (cth: 5 atau 0.2)" required>
                        </div>
                        <div class="form-text ps-2" style="font-size: 0.75rem;">
                            <i class="bi bi-info-circle me-1"></i> Nilai lebih tinggi berarti kriteria lebih prioritas.
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-dark opacity-75 text-uppercase mb-2" style="letter-spacing: 1px; font-size: 0.65rem;">Tipe Kriteria</label>
                        <div class="input-group-modern">
                            <span class="input-icon">
                                <i class="bi bi-arrow-down-up text-primary"></i>
                            </span>
                            <select name="tipe" class="form-control-modern pe-4" style="cursor: pointer;" required>
                                <option value="" disabled selected>Pilih Tipe...</option>
                                <option value="benefit">Benefit (Nilai tinggi = makin baik)</option>
                                <option value="cost">Cost (Nilai rendah = makin baik)</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2 mt-4 pt-2 border-top">
                        <button type="submit" class="btn btn-primary py-3 fw-bold rounded-4 shadow-primary hover-lift mt-2">
                            <i class="bi bi-check2-circle me-2"></i>Simpan Kriteria
                        </button>
                        <a href="<?= base_url('kriteria') ?>" class="btn btn-light py-3 fw-semibold rounded-4 text-muted border-0">
                            Batalkan
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card mt-4 border-0 shadow-sm" style="border-radius: 18px; background: linear-gradient(135deg, #fff9e6 0%, #fffdf5 100%); border-left: 5px solid #ffc107 !important;">
            <div class="card-body p-3 d-flex align-items-start">
                <div class="rounded-circle bg-white p-2 shadow-sm me-3">
                    <i class="bi bi-lightbulb-fill text-warning"></i>
                </div>
                <div>
                    <h6 class="small fw-bold text-dark mb-1">Tips Akurasi WP</h6>
                    <p class="text-muted mb-0" style="font-size: 0.75rem; line-height: 1.4;">
                        Pastikan pembobotan mencerminkan kepentingan real di lapangan. Total bobot tidak harus 100, namun konsistensi skala sangat disarankan.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Framework Visual */
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background: rgba(79, 70, 229, 0.1); }
    .shadow-primary { box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2) !important; }

    /* Icon Box Header */
    .icon-box-status {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }

    /* Modern Input Group */
    .input-group-modern {
        position: relative;
        display: flex;
        align-items: center;
        background: #f1f5f9;
        border-radius: 16px;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .input-icon {
        padding-left: 18px;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
    }

    .form-control-modern {
        background: transparent;
        border: none;
        padding: 14px 18px;
        width: 100%;
        color: #1e293b;
        font-weight: 500;
        outline: none;
        appearance: none; /* Untuk select agar bersih */
    }

    .input-group-modern:focus-within {
        background: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 10px 25px rgba(79, 70, 229, 0.08);
    }

    /* Effects */
    .hover-lift {
        transition: all 0.2s ease;
    }
    .hover-lift:hover {
        transform: translateY(-3px);
        opacity: 0.95;
    }

    /* Animation */
    .row {
        animation: slideUp 0.4s ease-out;
    }

    @keyframes slideUp {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?= $this->endSection() ?>