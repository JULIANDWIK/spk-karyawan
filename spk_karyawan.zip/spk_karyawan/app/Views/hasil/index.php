<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="d-none d-print-block text-center mb-5">
    <h3 class="fw-bold text-uppercase mb-1" style="font-family: 'Times New Roman', serif;">Laporan Hasil Penilaian Karyawan Terbaik</h3>
    <h4 class="fw-bold mb-1" style="font-family: 'Times New Roman', serif;">JULIET</h4>
    <p class="mb-0 small">Metode Perhitungan: Weighted Product (WP) | Periode: <?= date('F Y') ?></p>
    <hr style="border: 2px solid #000; opacity: 1; margin-top: 10px;">
    <hr style="border: 1px solid #000; opacity: 1; margin-top: -8px;">
</div>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 d-print-none">
    <div>
        <h3 class="fw-extrabold text-dark mb-1" style="letter-spacing: -1px;">Peringkat Akhir Karyawan</h3>
        <p class="text-muted small mb-0">Hasil rekomendasi keputusan otomatis menggunakan bobot preferensi WP.</p>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-white border shadow-sm px-4 fw-bold rounded-3" onclick="window.print()">
            <i class="bi bi-printer me-2 text-primary"></i> Cetak Laporan
        </button>
        
        <?php if (session()->get('role') == 'admin') : ?>
        <a href="<?= base_url('penilaian') ?>" class="btn btn-primary px-4 fw-bold shadow-primary rounded-3">
            <i class="bi bi-arrow-repeat me-2"></i> Hitung Ulang
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm overflow-hidden rounded-4">
    <div class="card-header bg-white py-3 border-bottom d-print-none">
        <div class="d-flex align-items-center">
            <div class="icon-box-sm bg-warning-soft text-warning me-2">
                <i class="bi bi-trophy-fill"></i>
            </div>
            <h5 class="mb-0 fw-bold text-dark" style="font-size: 1rem;">Daftar Rekomendasi Teratas</h5>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4 py-3 text-uppercase small fw-extrabold text-muted text-center" width="100">Rank</th>
                        <th class="py-3 text-uppercase small fw-extrabold text-muted">Profil Karyawan</th>
                        <th class="py-3 text-uppercase small fw-extrabold text-muted">Posisi / Jabatan</th>
                        <th class="py-3 text-uppercase small fw-extrabold text-muted text-center" width="200">Skor Preferensi (V)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1; 
                    if (!empty($ranking)) :
                        foreach($ranking as $r) : 
                            // Highlight untuk Ranking 1
                            $isFirst = ($no == 1);
                            $rowClass = $isFirst ? 'bg-rank-1' : '';
                            $badgeClass = $isFirst ? 'bg-warning text-white' : 'bg-light text-dark border';
                    ?>
                    <tr class="<?= $rowClass ?>">
                        <td class="text-center ps-4">
                            <span class="badge rounded-circle d-inline-flex align-items-center justify-content-center p-0 <?= $badgeClass ?>" style="width: 32px; height: 32px; font-weight: 800;">
                                <?= $no ?>
                            </span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="avatar-sm me-3 bg-white border shadow-sm rounded-circle d-flex align-items-center justify-content-center fw-bold d-print-none text-primary">
                                    <?= strtoupper(substr($r['nama_karyawan'] ?? 'K', 0, 1)) ?>
                                </div>
                                <div>
                                    <div class="fw-bold <?= $isFirst ? 'text-primary' : 'text-dark' ?>"><?= $r['nama_karyawan'] ?></div>
                                    <?php if($isFirst): ?>
                                        <span class="badge bg-primary-soft text-primary p-0 fw-bold" style="font-size: 0.65rem;">KANDIDAT TERBAIK</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="text-muted small fw-medium"><?= $r['posisi'] ?: '-' ?></span>
                        </td>
                        <td class="text-center">
                            <div class="fw-extrabold text-dark" style="font-size: 1.1rem;">
                                <?= number_format($r['nilai_v'], 4) ?>
                            </div>
                        </td>
                    </tr>
                    <?php 
                        $no++; 
                        endforeach; 
                    else : ?>
                        <tr>
                            <td colspan="4" class="text-center py-5">
                                <i class="bi bi-clipboard-x display-4 text-light"></i>
                                <p class="text-muted mt-2">Data hasil perhitungan belum tersedia.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if (!empty($ranking)) : ?>
<div class="card mt-4 border-0 shadow-sm bg-primary d-print-none rounded-4 overflow-hidden">
    <div class="card-body p-4 position-relative" style="z-index: 1;">
        <div class="d-flex align-items-center">
            <div class="me-4 d-none d-md-block">
                <i class="bi bi-cpu-fill display-4 text-white opacity-25"></i>
            </div>
            <div>
                <h6 class="fw-bold text-white mb-2">Simpulan Sistem Weighted Product</h6>
                <p class="mb-0 text-white opacity-75 small" style="line-height: 1.6;">
                    Berdasarkan normalisasi bobot dan perhitungan vektor V, karyawan <strong><?= $ranking[0]['nama_karyawan'] ?></strong> 
                    memiliki nilai tertinggi sebesar <strong><?= number_format($ranking[0]['nilai_v'], 4) ?></strong>. 
                    Hasil ini direkomendasikan secara sistem sebagai prioritas utama dalam pengambilan keputusan.
                </p>
            </div>
        </div>
    </div>
</div>

<div class="d-none d-print-block mt-5">
    <div class="row pt-5">
        <div class="col-8">
            <p class="small text-muted italic">Dicetak secara otomatis melalui Sistem Pendukung Keputusan (SPK) WP pada <?= date('d/m/Y H:i') ?></p>
        </div>
        <div class="col-4 text-center">
            <p class="mb-5 text-dark fw-bold">Purwokerto, <?= date('d F Y') ?><br>Mengetahui,<br>Kepala Bagian HRD</p>
            <br><br><br>
            <p class="fw-bold text-dark mb-0"><u>( ____________________ )</u></p>
            <p class="small text-muted">NIP. .........................</p>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
    /* Framework Visual */
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background: rgba(79, 70, 229, 0.1); }
    .bg-warning-soft { background: rgba(245, 158, 11, 0.1); }
    .bg-rank-1 { background-color: rgba(79, 70, 229, 0.04); }
    .shadow-primary { box-shadow: 0 8px 20px rgba(79, 70, 229, 0.2) !important; }
    
    .icon-box-sm {
        width: 32px; height: 32px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
    }

    .avatar-sm { width: 38px; height: 38px; font-size: 0.9rem; }

    .btn-white { background: #fff; color: #475569; }
    .btn-white:hover { background: #f8fafc; }

    /* Print Optimization */
    @media print {
        @page { size: portrait; margin: 1.5cm; }
        .d-print-none { display: none !important; }
        body { background: #fff !important; font-size: 12pt; }
        .card { border: none !important; box-shadow: none !important; }
        .table { width: 100% !important; border: 1px solid #000 !important; }
        .table th { background-color: #f0f0f0 !important; color: #000 !important; border-bottom: 2px solid #000 !important; }
        .table td { border-bottom: 1px solid #ccc !important; }
        .bg-rank-1 { background-color: transparent !important; }
        .text-primary { color: #000 !important; }
        .badge { border: 1px solid #000 !important; color: #000 !important; background: transparent !important; }
    }
</style>
<?= $this->endSection() ?>