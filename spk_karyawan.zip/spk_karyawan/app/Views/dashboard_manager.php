<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0 py-2">
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);">
                <div class="card-body p-4 p-md-5 position-relative">
                    <div class="row align-items-center position-relative" style="z-index: 1;">
                        <div class="col-md-8 text-white">
                            <h1 class="fw-extrabold display-6 mb-2" style="letter-spacing: -1.5px;">Executive Dashboard</h1>
                            <p class="lead opacity-75 mb-0">Halo, <strong><?= session()->get('nama_lengkap') ?></strong>! Berikut adalah rangkuman keputusan strategis berbasis metode WP.</p>
                        </div>
                        <div class="col-md-4 text-end d-none d-md-block text-white opacity-25">
                            <i class="bi bi-bar-chart-line" style="font-size: 8rem;"></i>
                        </div>
                    </div>
                    <div class="position-absolute bg-white opacity-10 rounded-circle" style="width: 300px; height: 300px; top: -100px; right: -50px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
                <div class="card-body p-4 text-center">
                    <div class="icon-box bg-primary-soft text-primary mx-auto mb-3" style="width: 50px; height: 50px; border-radius: 14px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-people-fill fs-4"></i>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1">Total Alternatif</h6>
                    <h2 class="fw-extrabold text-dark"><?= $total_alternatif ?></h2>
                    <span class="badge bg-light text-primary rounded-pill fw-medium">Karyawan Terdaftar</span>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
                <div class="card-body p-4 text-center">
                    <div class="icon-box bg-success-soft text-success mx-auto mb-3" style="width: 50px; height: 50px; border-radius: 14px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-check-circle-fill fs-4"></i>
                    </div>
                    <h6 class="text-muted text-uppercase small fw-bold mb-1">Status Keputusan</h6>
                    <h2 class="fw-extrabold text-success">FINAL</h2>
                    <span class="badge bg-light text-success rounded-pill fw-medium text-uppercase">Siap Digunakan</span>
                </div>
            </div>
        </div>

        <div class="col-md-12 col-xl-6">
            <div class="card border-0 shadow-sm rounded-4 h-100" style="background: #f8fafc; border: 2px dashed #e2e8f0 !important;">
                <div class="card-body d-flex flex-column flex-md-row align-items-center justify-content-around p-4 gap-3">
                    <div class="text-center text-md-start">
                        <h6 class="fw-bold text-dark mb-1">Aksi Cepat Laporan</h6>
                        <p class="text-muted small mb-0">Klik tombol untuk memproses data.</p>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?= base_url('hasil') ?>" class="btn btn-white shadow-sm rounded-pill px-4 fw-bold text-primary">
                            <i class="bi bi-trophy me-2"></i>Ranking
                        </a>
                        <a href="<?= base_url('hasil/cetak') ?>" target="_blank" class="btn btn-primary shadow-primary rounded-pill px-4 fw-bold">
                            <i class="bi bi-printer-fill me-2"></i>Cetak Hasil
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
                <div class="card-header bg-white py-4 border-0">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary p-2 rounded-3 me-3 text-white shadow-sm">
                            <i class="bi bi-graph-up"></i>
                        </div>
                        <h5 class="fw-bold mb-0 text-dark">Visualisasi Skor Karyawan (Top 5)</h5>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <div style="height: 350px;">
                        <canvas id="managerChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-dark position-relative overflow-hidden">
                <div class="card-body p-4 position-relative" style="z-index: 2;">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white p-2 rounded-3 me-3 shadow-sm">
                            <i class="bi bi-lightning-fill"></i>
                        </div>
                        <h5 class="fw-bold text-white mb-0">Informasi Sistem</h5>
                    </div>
                    
                    <div class="mb-4">
                        <p class="text-white opacity-75 small leading-relaxed">
                            Aplikasi ini menggunakan perhitungan <strong>Weighted Product (WP)</strong>. Nilai akhir didapatkan dari normalisasi bobot dan perkalian vektor S serta V.
                        </p>
                    </div>

                    <div class="list-group list-group-flush bg-transparent">
                        <div class="list-group-item bg-transparent border-secondary border-opacity-25 px-0 py-3 d-flex justify-content-between align-items-center">
                            <span class="text-white opacity-50 small">Total Kriteria</span>
                            <span class="badge bg-primary rounded-pill fw-bold"><?= $total_kriteria ?> Parameter</span>
                        </div>
                        <div class="list-group-item bg-transparent border-secondary border-opacity-25 px-0 py-3 d-flex justify-content-between align-items-center">
                            <span class="text-white opacity-50 small">Metode Digunakan</span>
                            <span class="text-primary fw-bold small">Weighted Product</span>
                        </div>
                        <div class="list-group-item bg-transparent border-0 px-0 py-3 d-flex justify-content-between align-items-center">
                            <span class="text-white opacity-50 small">Status Server</span>
                            <div class="d-flex align-items-center">
                                <div class="bg-success rounded-circle me-2" style="width: 8px; height: 8px;"></div>
                                <span class="text-success fw-bold small">Online</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="position-absolute bottom-0 end-0 p-3 opacity-10 text-white">
                    <i class="bi bi-gear-fill display-1"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('managerChart').getContext('2d');
    
    // Gradient Background for Chart
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(79, 70, 229, 0.9)');
    gradient.addColorStop(1, 'rgba(124, 58, 237, 0.1)');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($graph_labels) ?>,
            datasets: [{
                label: 'Nilai V (Preferensi Akhir)',
                data: <?= json_encode($graph_values) ?>,
                backgroundColor: gradient,
                borderColor: '#4f46e5',
                borderWidth: 0,
                borderRadius: 12,
                barThickness: 45,
                hoverBackgroundColor: '#4f46e5'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1e293b',
                    padding: 12,
                    titleFont: { size: 14, weight: 'bold' },
                    cornerRadius: 10
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { display: true, color: '#f1f5f9' },
                    border: { display: false }
                },
                x: {
                    grid: { display: false },
                    border: { display: false },
                    ticks: { font: { weight: '600', size: 12 } }
                }
            }
        }
    });
</script>

<style>
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background: rgba(79, 70, 229, 0.1); }
    .bg-success-soft { background: rgba(16, 185, 129, 0.1); }
    .shadow-primary { box-shadow: 0 10px 20px rgba(79, 70, 229, 0.15) !important; }
    .btn-white { background: #fff; color: #475569; }
    .btn-white:hover { background: #f8fafc; color: #4f46e5; }
    .leading-relaxed { line-height: 1.6; }

    /* Animation Entry */
    .card {
        animation: fadeIn 0.5s ease-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?= $this->endSection() ?>