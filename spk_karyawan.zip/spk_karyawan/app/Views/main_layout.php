<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPK WP | HR Analytics System</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-soft: rgba(99, 102, 241, 0.1);
            --sidebar-dark: #0b0f1a;
            --sidebar-accent: #1e293b;
            --bg-body: #f1f5f9;
            --sidebar-width: 280px;
        }

        body { 
            font-family: 'Inter', sans-serif; 
            background-color: var(--bg-body);
            color: #334155;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5, .sidebar-brand, .nav-label {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Sidebar Modern - Glass Effect */
        #sidebar {
            min-width: var(--sidebar-width);
            max-width: var(--sidebar-width);
            background: var(--sidebar-dark);
            min-height: 100vh;
            position: fixed;
            z-index: 1000;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 10px 0 30px rgba(0,0,0,0.1);
        }

        .sidebar-brand {
            padding: 32px 28px;
            font-size: 1.15rem;
            font-weight: 800;
            color: #fff;
            display: flex;
            align-items: center;
            letter-spacing: -0.5px;
        }

        .brand-icon {
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .nav-label {
            color: #475569;
            font-size: 0.7rem;
            text-transform: uppercase;
            font-weight: 800;
            padding: 20px 28px 12px;
            letter-spacing: 1.5px;
        }

        .nav-link {
            padding: 14px 28px;
            color: #94a3b8 !important;
            display: flex;
            align-items: center;
            font-weight: 500;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            margin: 4px 16px;
            border-radius: 12px;
        }

        .nav-link i {
            font-size: 1.2rem;
            margin-right: 14px;
            transition: transform 0.3s ease;
        }

        .nav-link:hover {
            color: #fff !important;
            background: var(--sidebar-accent);
        }

        .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-link.active {
            color: #fff !important;
            background: var(--primary);
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        /* Content Area Customization */
        #content {
            width: calc(100% - var(--sidebar-width));
            margin-left: var(--sidebar-width);
            transition: all 0.4s ease;
        }

        .top-navbar {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(12px);
            padding: 16px 40px;
            border-bottom: 1px solid rgba(226, 232, 240, 0.8);
            position: sticky;
            top: 0;
            z-index: 900;
        }

        .main-container {
            padding: 40px;
            min-height: calc(100vh - 140px);
        }

        /* Avatar & Profile Styling */
        .admin-profile {
            background: #fff;
            padding: 6px 6px 6px 16px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
        }

        .admin-profile:hover {
            border-color: var(--primary);
            background: #f8fafc;
        }

        .avatar {
            width: 38px;
            height: 38px;
            background: linear-gradient(135deg, #6366f1, #a855f7);
            color: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 13px;
            box-shadow: 0 4px 10px rgba(99, 102, 241, 0.2);
        }

        /* Custom Alert */
        .alert-modern {
            border-radius: 16px;
            border: none;
            background: #fff;
            border-left: 5px solid #10b981;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            padding: 20px;
        }

        footer {
            padding: 30px;
            color: #94a3b8;
            font-size: 0.85rem;
            background: transparent;
        }

        /* Responsive */
        @media (max-width: 992px) {
            #sidebar { margin-left: calc(-1 * var(--sidebar-width)); }
            #content { width: 100%; margin-left: 0; }
            #sidebar.active { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <nav id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">
                <i class="bi bi-cpu-fill"></i>
            </div>
            <span>HR ANALYTICS</span>
        </div>

        <div class="nav-label">Main Console</div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= (url_is('dashboard')) ? 'active' : '' ?>" href="<?= base_url('dashboard') ?>">
                    <i class="bi bi-grid-fill"></i> Dashboard
                </a>
            </li>
            
            <?php if (session()->get('role') == 'admin') : ?>
            <li class="nav-item">
                <a class="nav-link <?= (url_is('alternatif*')) ? 'active' : '' ?>" href="<?= base_url('alternatif') ?>">
                    <i class="bi bi-person-badge-fill"></i> Data Karyawan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= (url_is('kriteria*')) ? 'active' : '' ?>" href="<?= base_url('kriteria') ?>">
                    <i class="bi bi-command"></i> Kriteria WP
                </a>
            </li>
            <?php endif; ?>
        </ul>

        <div class="nav-label">Analysis Process</div>
        <ul class="nav flex-column">
            <?php if (session()->get('role') == 'admin') : ?>
            <li class="nav-item">
                <a class="nav-link <?= (url_is('penilaian*')) ? 'active' : '' ?>" href="<?= base_url('penilaian') ?>">
                    <i class="bi bi-patch-check-fill"></i> Input Penilaian
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link <?= (url_is('hasil*')) ? 'active' : '' ?>" href="<?= base_url('hasil') ?>">
                    <i class="bi bi-bar-chart-steps"></i> Hasil Peringkat
                </a>
            </li>
        </ul>
    </nav>

    <div id="content">
        <header class="top-navbar d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <button class="btn btn-light d-lg-none me-3" id="sidebarCollapse">
                    <i class="bi bi-list"></i>
                </button>
                <div class="search-bar d-none d-lg-flex align-items-center text-muted">
                    <i class="bi bi-search me-2"></i>
                    <span class="small">Search analytics...</span>
                </div>
            </div>
            
            <div class="dropdown">
                <div class="admin-profile d-flex align-items-center gap-3 dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" style="cursor:pointer">
                    <div class="text-end d-none d-sm-block">
                        <p class="mb-0 fw-bold small text-dark"><?= session()->get('nama_lengkap') ?? 'Administrator' ?></p>
                        <p class="mb-0 text-primary fw-bold" style="font-size: 10px; letter-spacing: 0.5px;"><?= strtoupper(session()->get('role') ?? 'GUEST') ?></p>
                    </div>
                    <div class="avatar">
                        <?= strtoupper(substr(session()->get('nama_lengkap') ?? 'AD', 0, 2)) ?>
                    </div>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-4 mt-2" aria-labelledby="userDropdown">
                    <li><h6 class="dropdown-header">Manage Account</h6></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item py-2 text-danger" href="<?= base_url('auth/logout') ?>"><i class="bi bi-box-arrow-right me-2"></i> Logout System</a></li>
                </ul>
            </div>
        </header>

        <main class="main-container">
            <?php if (session()->getFlashdata('success')) : ?>
                <div class="alert alert-modern d-flex align-items-center mb-4" id="auto-alert">
                    <i class="bi bi-check-circle-fill text-success fs-4 me-3"></i>
                    <div>
                        <h6 class="mb-0 fw-bold">Success!</h6>
                        <small class="text-muted"><?= session()->getFlashdata('success') ?></small>
                    </div>
                </div>
            <?php endif; ?>

            <div class="content-body">
                <?= $this->renderSection('content') ?>
            </div>
        </main>

        <footer class="text-center">
            <p class="mb-0">Powered by <strong>JULIET</strong> &bull; HR Analytics v2.0</p>
        </footer>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
    });

    // Auto-fade alert
    setTimeout(function() {
        const alert = document.getElementById('auto-alert');
        if(alert) {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }
    }, 4000);
</script>
</body>
</html>