<?= $this->extend('main_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h3 class="fw-extrabold text-dark mb-1" style="letter-spacing: -1px;">Matriks Penilaian</h3>
            <p class="text-muted small mb-0">Inputkan performa setiap karyawan berdasarkan kriteria untuk perhitungan WP.</p>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px; background: linear-gradient(to right, #f8fafc, #ffffff); border-left: 5px solid #4f46e5 !important;">
        <div class="card-body py-3 d-flex align-items-center">
            <div class="rounded-circle bg-primary-soft text-primary p-2 me-3 shadow-sm" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                <i class="bi bi-info-circle-fill"></i>
            </div>
            <div>
                <span class="fw-bold d-block text-dark small">Panduan Pengisian</span>
                <p class="text-muted mb-0" style="font-size: 0.75rem;">Gunakan angka desimal jika perlu (cth: 85.5). Pastikan skala nilai konsisten (misal: 1-100) di seluruh kriteria.</p>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 rounded-4 overflow-hidden bg-white">
        <div class="card-header bg-white py-3 border-bottom border-light">
            <div class="d-flex align-items-center">
                <i class="bi bi-grid-3x3 me-2 text-primary"></i>
                <h5 class="mb-0 fw-bold text-dark" style="font-size: 1rem;">Matriks Keputusan</h5>
            </div>
        </div>
        
        <div class="card-body p-0">
            <form action="<?= base_url('penilaian/simpan') ?>" method="post">
                <?= csrf_field() ?>
                
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 border-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4 py-3 sticky-col bg-light" style="min-width: 240px; z-index: 2;">
                                    <span class="text-uppercase small fw-extrabold text-muted">Data Karyawan</span>
                                </th>
                                <?php foreach($kriteria as $k) : ?>
                                    <th class="text-center py-3 border-start border-light" style="min-width: 130px;">
                                        <span class="d-block small fw-bold text-dark text-uppercase mb-1"><?= $k['nama_kriteria'] ?></span>
                                        <?php if (strtolower($k['tipe']) == 'benefit') : ?>
                                            <span class="badge rounded-pill bg-success-soft text-success border border-success-subtle fw-medium" style="font-size: 0.6rem;">
                                                <i class="bi bi-arrow-up me-1"></i>BENEFIT
                                            </span>
                                        <?php else : ?>
                                            <span class="badge rounded-pill bg-danger-soft text-danger border border-danger-subtle fw-medium" style="font-size: 0.6rem;">
                                                <i class="bi bi-arrow-down me-1"></i>COST
                                            </span>
                                        <?php endif; ?>
                                    </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($karyawan)) : ?>
                                <?php foreach($karyawan as $a) : ?>
                                <tr class="transition-all">
                                    <td class="ps-4 sticky-col bg-white">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-light text-primary rounded-circle me-3 fw-bold d-flex align-items-center justify-content-center" style="width: 35px; height: 35px; font-size: 0.8rem;">
                                                <?= substr($a['nama_karyawan'], 0, 1) ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-dark small mb-0"><?= $a['nama_karyawan'] ?></div>
                                                <div class="text-muted" style="font-size: 0.7rem;"><?= $a['posisi'] ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <?php foreach($kriteria as $k) : ?>
                                        <td class="p-3 border-start border-light text-center">
                                            <?php 
                                                $val = '';
                                                if (isset($nilai[$a['id_alternatif']][$k['id_kriteria']])) {
                                                    $val = $nilai[$a['id_alternatif']][$k['id_kriteria']];
                                                }
                                            ?>
                                            <input type="number" step="0.01" 
                                                   name="nilai[<?= $a['id_alternatif'] ?>][<?= $k['id_kriteria'] ?>]" 
                                                   class="form-control-penilaian mx-auto" 
                                                   value="<?= $val ?>" 
                                                   placeholder="0"
                                                   required>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="<?= count($kriteria) + 1 ?>" class="text-center py-5">
                                        <div class="py-4">
                                            <i class="bi bi-person-exclamation display-4 text-light"></i>
                                            <p class="text-muted mt-2">Data karyawan belum diinputkan.</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="p-4 bg-light-subtle d-flex justify-content-between align-items-center border-top">
                    <a href="<?= base_url('dashboard') ?>" class="btn btn-outline-secondary px-4 rounded-3 fw-semibold small border-light-subtle bg-white">
                        <i class="bi bi-house-door me-2"></i>Dashboard
                    </a>
                    <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-primary rounded-3">
                        <i class="bi bi-cloud-check me-2"></i>Simpan Perubahan Matriks
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* Framework */
    .fw-extrabold { font-weight: 800; }
    .bg-primary-soft { background: rgba(79, 70, 229, 0.1); }
    .bg-success-soft { background: rgba(16, 185, 129, 0.1); }
    .bg-danger-soft { background: rgba(239, 68, 68, 0.1); }
    .shadow-primary { box-shadow: 0 8px 16px rgba(79, 70, 229, 0.2) !important; }

    /* Sticky Column (Nama Karyawan tidak hilang saat geser) */
    .sticky-col {
        position: sticky;
        left: 0;
        border-right: 1px solid #f1f5f9 !important;
    }

    /* Custom Input Style */
    .form-control-penilaian {
        max-width: 85px;
        height: 38px;
        border-radius: 10px;
        border: 2px solid #f1f5f9;
        background-color: #f8fafc;
        text-align: center;
        font-weight: 700;
        color: #1e293b;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .form-control-penilaian:focus {
        background-color: #ffffff;
        border-color: #4f46e5;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.12);
        transform: translateY(-2px);
        outline: none;
    }

    /* Table Decoration */
    .transition-all { transition: all 0.2s; }
    .table thead th { border: none; }
    
    .table-hover tbody tr:hover {
        background-color: #fcfdfe !important;
    }

    .table-hover tbody tr:hover td.sticky-col {
        background-color: #fcfdfe !important;
    }

    /* Avatar Sm */
    .avatar-sm {
        border: 2px solid #fff;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
</style>
<?= $this->endSection() ?>